<?php
date_default_timezone_set('Europe/Madrid');
setlocale(LC_TIME, 'es_ES.UTF-8');
$fechaHoy = strftime("📅 Actualizado el %e de %B de %Y");

// ID de tu hoja de cálculo
$sheetID = '1r9aQ3_VtdHi05VRlGLb0aejr4CuMNksgljhiQ3MWGf0';
$url = "https://opensheet.elk.sh/$sheetID/1";

// Leer y decodificar JSON
$contenido = file_get_contents($url);
$datos = json_decode($contenido, true);

// Tomar solo las últimas 20 noticias
$ultimas = array_slice($datos, 0, 20);

// Preparar datos para JavaScript
foreach ($ultimas as &$n) {
    if (isset($n[""]) && !isset($n["Imagen"])) {
        $n["Imagen"] = $n[""];
        unset($n[""]);
    }
    if (empty($n['Imagen']) || !filter_var($n['Imagen'], FILTER_VALIDATE_URL)) {
        $n['Imagen'] = 'https://via.placeholder.com/600x400?text=Sin+imagen';
    }
}
unset($n);

$noticiasJSON = json_encode($ultimas, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

$html = <<<HTML
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Noticias Digitales - Creawebes</title>
  <meta name="description" content="Noticias actualizadas del mundo digital.">
  <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Lato', sans-serif;
      background: #fff;
      color: #222;
      margin: 0;
      padding: 2rem;
      min-height: 100vh;
    }
    #slider {
      max-width: 700px;
      margin: 0 auto;
      text-align: center;
      min-height: 600px;
    }
    .noticia {
      display: none;
    }
    .noticia.active {
      display: block;
    }
    img {
      max-width: 100%;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.08);
      margin-bottom: 1rem;
    }
    h2 {
      font-size: 1.5rem;
      margin-bottom: 0.5rem;
    }
    .autor, .fecha {
      font-size: 0.9rem;
      color: #555;
    }
    .boton {
      display: inline-block;
      margin-top: 0.8rem;
      padding: 0.6rem 1.2rem;
      background-color: #3949ab;
      color: #fff;
      text-decoration: none;
      border-radius: 8px;
    }
  </style>
</head>
<body>
  <h1 style="text-align:center;">📰 Últimas Noticias</h1>

  <div id="slider"></div>

  <script>
    const noticias = $noticiasJSON;
    const slider = document.getElementById("slider");
    const fechaActual = `$fechaHoy`;

    noticias.forEach((noticia, i) => {
      const div = document.createElement("div");
      div.className = "noticia" + (i === 0 ? " active" : "");
      div.innerHTML = `
        <img src="\${noticia.Imagen}" alt="Imagen de noticia">
        <h2>\${noticia.Titulo}</h2>
        <p class="autor">👤 \${noticia.Autor}</p>
        <a class="boton" href="\${noticia.Url}" target="_blank" rel="noopener">Leer más</a>
        <p class="fecha">\${fechaActual}</p>
      `;
      slider.appendChild(div);
    });

    let current = 0;
    setInterval(() => {
      const items = document.querySelectorAll(".noticia");
      items[current].classList.remove("active");
      current = (current + 1) % items.length;
      items[current].classList.add("active");
    }, 10000);
  </script>
</body>
</html>
HTML;

file_put_contents("index.html", $html);
echo "✅ Diapositiva HTML generada correctamente con fecha de actualización al pie.";
?>
