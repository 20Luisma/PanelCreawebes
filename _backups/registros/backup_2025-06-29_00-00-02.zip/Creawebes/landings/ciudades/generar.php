<?php



// Configuración inicial
$spreadsheetId = '120cXBPsa47cBpVwPgGhz0NGEpOTM-AubKps8so6GKv0';
$gids = ['ciudades' => '2096882059', 'municipios' => '1714039620'];
$outputDir = __DIR__ . "/HTMLS/";
$apiKey = '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'; // Poné tu API KEY válida 
$porLote = 20;
$imagenBase = "https://contenido.creawebes.com/Creawebes/landings/ciudades/Imagenes/";

if (!is_dir($outputDir)) mkdir($outputDir, 0777, true);
session_start();

// Paso 1: Borrar HTMLs y mostrar total
if (!isset($_GET['accion'])) {
    $archivos = glob($outputDir . '*.html');
    $borrados = count($archivos);
    foreach ($archivos as $f) unlink($f);
    $_SESSION['offset'] = 0;
    unset($_SESSION['filas']);
    echo "<h2>Se han eliminado $borrados archivos HTML.</h2>";
    echo "<form method='get'><input type='hidden' name='accion' value='generar'><button>Comenzar generación</button></form>";
    exit;
}

// Paso 2: Cargar todas las filas una vez
if (!isset($_SESSION['filas'])) {
    $filasTotales = [];
    foreach ($gids as $gid) {
        $url = "https://docs.google.com/spreadsheets/d/$spreadsheetId/gviz/tq?tqx=out:csv&gid=$gid";
        $csv = @file_get_contents($url);
        if (!$csv) continue;
        $filas = array_map("str_getcsv", explode("\n", $csv));
        array_shift($filas);
        foreach ($filas as $fila) {
            if (count($fila) >= 6) $filasTotales[] = $fila;
        }
    }
    $_SESSION['filas'] = $filasTotales;
}

$filas = $_SESSION['filas'];
$offset = $_SESSION['offset'] ?? 0;

function llamarGPT($prompt, $apiKey) {
    $data = [
        "model" => "gpt-3.5-turbo",
        "messages" => [["role" => "user", "content" => $prompt]],
        "temperature" => 0.7
    ];
    $ch = curl_init("https://api.openai.com/v1/chat/completions");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer $apiKey"
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data)
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);
    return $result['choices'][0]['message']['content'] ?? "Contenido optimizado para tu ciudad.";
}

$generados = 0;
$total = count($filas);
for ($i = $offset; $i < min($offset + $porLote, $total); $i++) {
    [$ciudad, $slug, $titulo, $descripcion, $h1, $imagen] = $filas[$i];
    if (!preg_match('/^[a-z0-9\-]+$/', $slug)) continue;
    $descripcionIA = llamarGPT("Escribe una frase breve y profesional para una agencia de diseño web moderno en $ciudad. Máx. 20 palabras.", $apiKey);

    $html = <<<HTML
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>$titulo</title>
  <meta name="description" content="$descripcionIA" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
  <script type="application/ld+json">{
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Creawebes",
    "url": "https://www.creawebes.com",
    "logo": "{$imagenBase}creawebes.png",
    "image": "{$imagenBase}creawebes.png",
    "description": "$descripcionIA",
    "address": {
        "@type": "PostalAddress",
        "addressLocality": "$ciudad",
        "addressCountry": "ES"
    },
    "areaServed": "$ciudad",
    "priceRange": "€€"
  }</script>
 <style>
  body { margin: 0; font-family: 'Lato', sans-serif; background-color: #f9f9f9; color: #222; }
  header { background: #e3f2fd; color: #222; padding: 2rem; text-align: center; }
  main { padding: 2rem; max-width: 800px; margin: auto; background: white; box-shadow: 0 0 15px rgba(0,0,0,0.05); margin-top: -1.5rem; border-radius: 1rem; }
  img { max-width: 100%; border-radius: 0.5rem; margin-bottom: 1rem; }
  .cta { margin-top: 2rem; text-align: center; }
  .cta a { background-color: #3949ab; color: white; padding: 0.75rem 1.5rem; border-radius: 0.5rem; text-decoration: none; font-weight: bold; }
  .extra { margin-top: 3rem; }
  .extra h2 { color: #3949ab; margin-top: 2rem; text-align: center; } /* CENTRADO */
  footer { text-align: center; padding: 1rem; margin-top: 2rem; font-size: 0.9rem; color: #666; }
</style>

</head>
<body>
  <header>
    <h1>$h1</h1>
  </header>
  <main>
    <img src="{$imagenBase}{$imagen}" alt="Diseño web en $ciudad">
    <p style="text-align: center;">$descripcionIA</p>
    <div class="cta">
      <a href="https://www.creawebes.com">Visita Creawebes</a>
    </div>
    <div class="extra">
      <h2>Planes Web IA</h2>
      <p>Elige el plan que mejor se adapte a tu negocio. Todos los sitios son entregados en pocos días y son totalmente editables.</p>
   <ul>
  <li><strong>🟦 Starter</strong>: Landing de una sola sección – 99 €</li>
  <li><strong>🟨 Profesional</strong>: Hasta 4 secciones – 149 €</li>
  <li><strong>🟩 Tienda IA</strong>: Catálogo hasta 10 productos – Desde 249 €</li>
  <li><strong>🟥 Web IA + Automatizada</strong>: Blog dinámico SEO – Desde 350 €</li>
  <li><strong>🟪 Panel Web Personalizado</strong>: Acceso privado y gestión online – Desde 120 €</li>
</ul>

      <p><em>* Esta página se desarrollará utilizando el generador de Hostinger. El dominio y el hosting no están incluidos en el precio final. Puedes contratarlos por tu cuenta o, si lo prefieres, te ayudamos a gestionarlos.</em></p>
      <h2>¿Por qué elegir nuestros servicios?</h2>
      <p>Nuestros planes están respaldados por la infraestructura de Hostinger, una de las plataformas líderes en hosting y creación de sitios web.</p>
      <ul>
        <li>✔️ Editor intuitivo de arrastrar y soltar</li>
        <li>✔️ Más de 150 plantillas profesionales</li>
        <li>✔️ Herramientas de IA integradas</li>
        <li>✔️ Dominio gratuito con planes anuales</li>
        <li>✔️ Soporte 24/7 en español</li>
      </ul>
      <p><strong>Nota sobre los precios:</strong> Los precios del diseño y tiempos pueden variar según la complejidad. Desde 99 € hasta 1.200 €, dependiendo del tipo de web y funcionalidades.</p>
    </div>
  </main>
  <footer>
    © 2025 Creawebes · Agencia de diseño web en $ciudad
  </footer>
</body>
</html>

HTML;

    file_put_contents("$outputDir/$slug.html", $html);
    $generados++;
}

$_SESSION['offset'] += $porLote;

if ($_SESSION['offset'] < $total) {
    $restantes = $total - $_SESSION['offset'];
    echo "<h3>Se han generado $generados archivos.</h3>";
    echo "<p>Quedan $restantes por generar.</p>";
    echo "<form method='get'><input type='hidden' name='accion' value='generar'><button>Continuar</button></form>";
} else {
    unset($_SESSION['filas'], $_SESSION['offset']);

    $archivosHTML = glob($outputDir . '*.html');
    $totalGenerados = count($archivosHTML);

    $urls = array_map(function($archivo) {
        $nombreArchivo = basename($archivo);
        $slug = pathinfo($nombreArchivo, PATHINFO_FILENAME);
        return "<url><loc>https://contenido.creawebes.com/Creawebes/landings/ciudades/HTMLS/$slug.html</loc><lastmod>" . date('c') . "</lastmod><changefreq>monthly</changefreq><priority>0.8</priority></url>\n";
    }, $archivosHTML);

    $sitemap = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $sitemap .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    $sitemap .= implode("", $urls);
    $sitemap .= "</urlset>\n";

    file_put_contents(__DIR__ . "/sitemap.xml", $sitemap);

    echo "<h2>✅ Todos los HTML generados correctamente.</h2>";
    echo "<p>Se crearon $totalGenerados archivos HTML.</p>";
    echo "<p>Sitemap generado correctamente con $totalGenerados URLs.</p>";
    echo "<p>🕓 Finalizado el " . date('d/m/Y H:i:s') . "</p>";
}
?>