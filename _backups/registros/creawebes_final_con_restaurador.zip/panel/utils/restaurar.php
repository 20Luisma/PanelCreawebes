<?php
session_start();
if (!isset($_SESSION['logueado']) || $_SESSION['logueado'] !== true) {
    echo "❌ Acceso denegado. Debes iniciar sesión.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Restaurar Sistema - Creawebes</title>
  <style>
    body { font-family: sans-serif; background: #f2f2f2; padding: 2rem; }
    .container { max-width: 500px; margin: auto; background: #fff; padding: 2rem; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    h2 { text-align: center; }
    input, button { width: 100%; padding: 10px; margin-top: 1rem; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Restaurar Sistema desde ZIP</h2>
    <form action="restaurar_proc.php" method="post" enctype="multipart/form-data">
      <input type="file" name="zip" accept=".zip" required>
      <input type="hidden" name="token" value="alfred_2025">
      <button type="submit">✅ Restaurar sistema completo</button>
    </form>
  </div>
</body>
</html>