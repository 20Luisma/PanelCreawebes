<?php
session_start();
$tokenValido = 'alfred_2025';
$token = $_POST['token'] ?? '';

if (!isset($_SESSION['logueado']) && $token !== $tokenValido) {
    http_response_code(403);
    exit('❌ Acceso no autorizado.');
}

$zipFile = $_FILES['zip']['tmp_name'] ?? '';
$zipName = $_FILES['zip']['name'] ?? '';
$root = realpath(__DIR__ . '/../..');
$excluir = ['panel/utils/restaurar.php', 'panel/utils/restaurar_proc.php'];

if (!$zipFile || pathinfo($zipName, PATHINFO_EXTENSION) !== 'zip') {
    exit('❌ Archivo inválido. Solo se permiten archivos .zip');
}

$archivos = scandir($root);
foreach ($archivos as $item) {
    if ($item === '.' || $item === '..' || in_array($item, $excluir)) continue;

    $ruta = $root . DIRECTORY_SEPARATOR . $item;
    if (is_dir($ruta)) {
        exec("rm -rf " . escapeshellarg($ruta));
    } else {
        unlink($ruta);
    }
}

$zip = new ZipArchive;
if ($zip->open($zipFile) === TRUE) {
    $zip->extractTo($root);
    $zip->close();
    echo '✅ Sistema restaurado correctamente desde ' . htmlspecialchars($zipName);
} else {
    exit('❌ No se pudo extraer el ZIP.');
}
?>