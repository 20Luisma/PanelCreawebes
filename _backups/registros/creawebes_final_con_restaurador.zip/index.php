<?php
session_start();
if (!isset($_SESSION['logueado']) || $_SESSION['logueado'] !== true) {
    header('Location: login.php');
    exit;
}
/* =========================================================
 *  Explorador de Archivos – Creawebes (versión 14-jun-2025)
 *  Ahora pregunta si se quiere reemplazar cuando al mover
 *  existe un archivo o carpeta con el mismo nombre.
 * =======================================================*/

// ---------- Ajustes iniciales ----------
$root            = realpath(__DIR__);          // Carpeta raíz
$carpetaRelativa = $_GET['carpeta'] ?? '';     // Carpeta actual (relativa)
$error           = $_GET['error']   ?? '';     // Código de error
$rutaActual      = realpath($root . '/' . $carpetaRelativa);
if (!$rutaActual || strpos($rutaActual, $root) !== 0) die("Ruta inválida.");

// ---------- Helpers ----------
function obtenerRutaRelativa($root, $abs) {
    return ltrim(str_replace($root, '', $abs), '/\\');
}
function iconoArchivo($n) {
    $ext = strtolower(pathinfo($n, PATHINFO_EXTENSION));
    return match ($ext) {
        'jpg','jpeg','png','gif','webp' => '🖼️',
        'pdf'                           => '📄',
        'php','html','js','css'         => '💻',
        'zip','rar'                     => '🗜️',
        'mp3','wav'                     => '🎵',
        'mp4','mov'                     => '🎞️',
        default                         => '📄',
    };
}
function breadcrumb($rel) {
    if (!$rel) return '📁 <strong>Inicio</strong>';
    $p   = explode('/', $rel);
    $out = ['<a href="index.php">Inicio</a>'];
    $acc = [];
    foreach ($p as $seg) {
        $acc[] = $seg;
        $out[] = '<a href="index.php?carpeta=' . urlencode(implode('/', $acc)) . '">' .
                 htmlspecialchars($seg) . '</a>';
    }
    return '📁 ' . implode(' / ', $out);
}
function duplicarCarpeta($src, $dst) {
    mkdir($dst);
    foreach (scandir($src) as $i) {
        if ($i === '.' || $i === '..') continue;
        $s = "$src/$i";
        $d = "$dst/$i";
        is_dir($s) ? duplicarCarpeta($s, $d) : copy($s, $d);
    }
}
/* Elimina recursivamente archivos o carpetas (para sobrescribir) */
function eliminarRecursivo($ruta) {
    if (is_dir($ruta) && !is_link($ruta)) {
        foreach (scandir($ruta) as $i) {
            if ($i === '.' || $i === '..') continue;
            eliminarRecursivo("$ruta/$i");
        }
        rmdir($ruta);
    } elseif (file_exists($ruta)) {
        unlink($ruta);
    }
}
function listarCarpetas($ruta, $base = '', $root = '') {
    $root = $root ?: $ruta;
    $out  = [];
    foreach (scandir($ruta) as $i) {
        if ($i === '.' || $i === '..') continue;
        $abs = "$ruta/$i";
        if (is_dir($abs)) {
            $rel  = ltrim("$base/$i", '/');
            $out[] = $rel;
            $out   = array_merge($out, listarCarpetas($abs, $rel, $root));
        }
    }
    return $out;
}

/* ---------- API para <select> de destinos ---------- */
if (isset($_GET['listar'])) {
    header('Content-Type: application/json');
    $todas  = listarCarpetas($root);
    $actual = $_GET['actual'] ?? '';
    echo json_encode(array_values(array_filter(
        array_merge([''], $todas),
        fn($c) => $c !== $actual        // quita la carpeta actual
    )));
    exit;
}

/* ---------- Acciones POST ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $accion      = $_POST['accion']  ?? '';
    $objetivo    = basename($_POST['archivo'] ?? '');
    $rutaObjAbs  = $rutaActual . '/' . $objetivo;

    /* ---------- Subida de archivo ---------- */
    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
        move_uploaded_file($_FILES['archivo']['tmp_name'],
                           $rutaActual . '/' . basename($_FILES['archivo']['name']));
        header('Location: index.php?carpeta=' . urlencode($carpetaRelativa));
        exit;
    }

    /* ---------- Resto de acciones ---------- */
    switch ($accion) {

        case 'eliminar':
            is_file($rutaObjAbs) ? unlink($rutaObjAbs) : eliminarRecursivo($rutaObjAbs);
            break;

        case 'renombrar':
            $nuevo = basename($_POST['nuevo_nombre']);
            if (!file_exists($rutaActual . '/' . $nuevo)) {
                rename($rutaObjAbs, $rutaActual . '/' . $nuevo);
            } else {
                header('Location: index.php?carpeta=' . urlencode($carpetaRelativa) .
                       '&error=existe');
                exit;
            }
            break;

        case 'duplicar':
            $copia = $rutaActual . '/copia_' . $objetivo;
            if (!file_exists($copia)) {
                is_file($rutaObjAbs) ? copy($rutaObjAbs, $copia)
                                     : duplicarCarpeta($rutaObjAbs, $copia);
            } else {
                header('Location: index.php?carpeta=' . urlencode($carpetaRelativa) .
                       '&error=existe');
                exit;
            }
            break;

        case 'crear_carpeta':
            $nombre = basename($_POST['nueva_carpeta']);
            if (!file_exists($rutaActual . '/' . $nombre)) {
                mkdir($rutaActual . '/' . $nombre);
            } else {
                header('Location: index.php?carpeta=' . urlencode($carpetaRelativa) .
                       '&error=existe');
                exit;
            }
            break;

        case 'crear_archivo':
            $nombreArchivo = basename($_POST['nombre_archivo']);
            $contenido     = $_POST['contenido'] ?? '';
            if (!file_exists($rutaActual . '/' . $nombreArchivo)) {
                file_put_contents($rutaActual . '/' . $nombreArchivo, $contenido);
            } else {
                header('Location: index.php?carpeta=' . urlencode($carpetaRelativa) .
                       '&error=existe');
                exit;
            }
            break;

        /* ---------- Mover archivo / carpeta ---------- */
        case 'mover':
            $destinoRel   = trim($_POST['destino'] ?? '');
            $rutaDestAbs  = $destinoRel === '' ? $root
                                               : realpath($root . '/' . $destinoRel);
            if ($rutaDestAbs && strpos($rutaDestAbs, $root) === 0 &&
                realpath($rutaDestAbs) !== realpath($rutaActual)) {

                $nuevaRutaAbs = $rutaDestAbs . '/' . $objetivo;
                $forzar       = ($_POST['forzar'] ?? '') === '1';

                if (file_exists($nuevaRutaAbs) && !$forzar) {
                    /* Conflicto → redirige para preguntar */
                    header('Location: index.php?carpeta=' . urlencode($carpetaRelativa) .
                           '&error=conflicto&archivo=' . urlencode($objetivo) .
                           '&destino=' . urlencode($destinoRel));
                    exit;
                }

                /* Si forzar o no existe destino → mover */
                if (file_exists($nuevaRutaAbs) && $forzar) {
                    eliminarRecursivo($nuevaRutaAbs);
                }
                rename($rutaObjAbs, $nuevaRutaAbs);

                /* Muestra ahora la carpeta destino */
                header('Location: index.php?carpeta=' . urlencode($destinoRel));
                exit;
            }
            break;
    }

    /* Todas las acciones que llegan aquí vuelven a la carpeta actual */
    header('Location: index.php?carpeta=' . urlencode($carpetaRelativa));
    exit;
}

/* ---------- Listado de elementos ----------
   (sólo HTML a partir de aquí) */
$orden = $_GET['orden'] ?? 'nombre';
$dir   = $_GET['dir'] ?? 'asc'; // asc o desc
$items = array_filter(scandir($rutaActual), fn($i) => $i !== '.' && $i !== '..');
usort($items, function ($a, $b) use ($rutaActual, $orden, $dir) {
    $pa = $rutaActual . '/' . $a;
    $pb = $rutaActual . '/' . $b;

    $esDirA = is_dir($pa);
    $esDirB = is_dir($pb);

    // Carpetas primero
    if ($esDirA && !$esDirB) return -1;
    if (!$esDirA && $esDirB) return 1;

    // Comparación según orden
    switch ($orden) {
        case 'fecha':
            $res = filemtime($pa) <=> filemtime($pb);
            break;
        case 'tipo':
            $extA = strtolower(pathinfo($a, PATHINFO_EXTENSION));
            $extB = strtolower(pathinfo($b, PATHINFO_EXTENSION));
            $res = $extA <=> $extB;
            if ($res === 0) $res = strcasecmp($a, $b);
            break;
        case 'nombre':
        default:
            $res = strcasecmp($a, $b);
    }

    return $dir === 'desc' ? -$res : $res;
});

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Explorador – <?= htmlspecialchars($carpetaRelativa ?: 'Inicio') ?></title>
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
<style>
  body{font-family:'Lato',sans-serif;background:#e3f2fd;margin:0;padding:3rem;color:#222}
  .titulo-principal{text-align:center;font-size:4rem;margin-bottom:1rem;color:#3949ab}
  .explorador {
    max-width: 1100px;
    background: #fff;
    border: 1px solid #ccc;
    padding: 3rem;
    border-radius: 1.5rem;
    margin: auto;
    box-shadow: 0 0 25px rgba(0, 0, 0, .06);
  }
  .volver {
  margin-top: 2rem;
  font-size: 1rem;
}
.volver a {
  color: #3949ab;
  text-decoration: none;
  font-weight: bold;
}
  .breadcrumb{margin-bottom:1rem;font-size:.95rem;color:#555}
  .breadcrumb a{color:#3949ab;text-decoration:none}
  .error{background:#ffdede;color:#b20000;padding:.8rem;border-radius:.5rem;margin-bottom:1rem}
  .acciones-top{margin:1.5rem 0}
  ul{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:1rem}
  li{background:#f0f4ff;padding:.8rem 1rem;border-radius:.5rem;min-width:240px;position:relative;cursor:context-menu}
  li img.preview{display:none;position:absolute;max-width:200px;top:2.5rem;left:0;box-shadow:0 0 10px rgba(0,0,0,.2);border-radius:.3rem;z-index:999}
  li:hover img.preview{display:block}
  .menu{position:absolute;z-index:999;background:#fff;border:1px solid #ccc;border-radius:6px;box-shadow:0 0 10px rgba(0,0,0,.1);display:none}
  .menu button{display:block;background:none;border:none;padding:.3rem 1rem;width:100%;text-align:left;cursor:pointer}
  .menu button:hover{background:#eee}
  .btn-top{margin:.3rem 0;background:#3949ab;color:#fff;border:none;padding:.5rem 1rem;border-radius:.4rem;cursor:pointer}
  .modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:#0008;justify-content:center;align-items:center}
  .modal-content{background:white;padding:2rem;border-radius:10px;width:90%;max-width:500px}
  .footer{text-align:center;padding:2rem;color:#888;font-size:0.9rem}

#btnAlfred {
  position: fixed;
  bottom: 100px;
  right: 2rem;
  background-color: #3949ab;
  color: white;
  font-size: 0.9rem;
  font-weight: 600;
  padding: 0.5rem 1rem;
  border-radius: 999px;
  text-decoration: none;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
  z-index: 999;
  transition: background-color 0.3s;
}
#btnAlfred:hover {
  background-color: #303f9f;
}



</style>
</head>
<body>


<div style="text-align:right; margin-top:-3rem; margin-bottom:2rem;">
  <a href="logout.php" style="color:#3949ab; font-weight:bold; text-decoration:none;">🔓 Cerrar sesión</a>
</div>
<div class="explorador">
  <h1>📁 Explorador de Archivos</h1>

  <div class="breadcrumb"><?= breadcrumb($carpetaRelativa) ?></div>

  <?php if ($error === 'existe'): ?>
    <div class="error">❌ Ya existe un archivo o carpeta con ese nombre.</div>
  <?php endif; ?>

  <!-- Conflicto al mover: se mostrará después como modal -->
  <?php /* El modal de conflicto se inyecta más abajo */ ?>

<div class="acciones-top">
  <button class="btn-top" onclick="crearCarpeta()">📁 Nueva carpeta</button>
  <button class="btn-top" onclick="mostrarSubida()">📤 Subir archivo</button>
  <button class="btn-top" onclick="window.open('https://contenido.creawebes.com/CrearNuevo%20Archivo.php?carpeta=<?= urlencode($carpetaRelativa) ?>', '_blank')">📝 Crear documento</button>
  <button class="btn-top" onclick="window.open('https://script.google.com/macros/s/AKfycbwUfLvcB_o9k3fMW52Iz984UoFN6TYc0K9ntPpq1_MbA-Drvj_MOn4ur0-6aDkfu_x8/exec', '_blank')">📅 Agenda</button>
<button class="btn-top" onclick="abrirWhatsapp()">💬 WhatsApp Web</button>
<form action="buscar.php" method="get" style="margin: 2rem 0 1rem 0;">
  <input type="text" name="q" id="buscador" placeholder="🔍 Buscar archivo o carpeta..." style="width: 100%; padding: 0.6rem; border-radius: 6px; border: 1px solid #ccc;">
</form>
<div id="resultadosBusqueda" style="margin-top: 2rem;"></div>




</div>



  <div id="subida" style="display:none;margin:1rem 0;">
    <form method="POST" enctype="multipart/form-data">
      <input type="file" name="archivo" required style="margin-right:1rem;">
      <button type="submit">⬆️ Subir</button>
    </form>
  </div>
<!-- Controles de orden, copia y restauración -->
<div class="acciones-top" style="display: flex; flex-wrap: wrap; gap: 1rem; align-items: center; margin-bottom: 1.5rem;">
  <!-- Botón Ordenar -->
  <div style="position: relative;">
    <button class="btn-top" onclick="toggleMenuOrden()">Ordenar ▾</button>
    <div id="menuOrden" style="display:none;position:absolute;background:#f9f9f9;border:1px solid #ddd;padding:.3rem .8rem;border-radius:.3rem;box-shadow:none;z-index:1000;">
      <?php
        $orden = $_GET['orden'] ?? 'nombre';
        $dir   = $_GET['dir'] ?? 'asc';
        $base  = 'index.php?carpeta=' . urlencode($carpetaRelativa);

        function linkOrden($nombre, $campo, $dir, $actualOrden, $actualDir, $base) {
            $activo = ($campo === $actualOrden && $dir === $actualDir) ? 'font-weight:bold;color:#3949ab;' : 'color:#333;';
            $url = "$base&orden=$campo&dir=$dir";
            return "<div style='margin: .2rem 0;'><a href=\"$url\" style=\"$activo text-decoration:none; display:block; padding:.2rem 0; font-size: 0.95rem; font-family: Lato, sans-serif;\">$nombre</a></div>";
        }

        echo linkOrden('Nombre (A-Z)', 'nombre', 'asc', $orden, $dir, $base);
        echo linkOrden('Nombre (Z-A)', 'nombre', 'desc', $orden, $dir, $base);
        echo linkOrden('Tipo (A-Z)', 'tipo', 'asc', $orden, $dir, $base);
        echo linkOrden('Tipo (Z-A)', 'tipo', 'desc', $orden, $dir, $base);
        echo linkOrden('Fecha (recientes primero)', 'fecha', 'desc', $orden, $dir, $base);
        echo linkOrden('Fecha (más antiguas)', 'fecha', 'asc', $orden, $dir, $base);
      ?>
    </div>
  </div>

  <!-- Botón Copia de seguridad -->
  <form id="backupForm" method="POST" action="backup.php">
    <input type="hidden" name="accion" value="backup">
    <button class="btn-top" type="submit" onclick="return confirm('¿Crear copia de seguridad?')">
      ♻️ Copia de seguridad
    </button>
  </form>

 <!-- Botón Restaurar copia -->
<form method="GET" action="restaurar.php" style="display:inline;">
  <button class="btn-top" type="submit" onclick="return confirm('¿Ir a restaurar una copia?')">
    🔄 Restaurar copia
  </button>
</form>

<ul>
<?php
foreach ($items as $item):
    $rutaCompleta = $rutaActual . '/' . $item;
    $relativa     = obtenerRutaRelativa($root, $rutaCompleta);
    $dir          = is_dir($rutaCompleta);
    $esImagen     = !$dir && preg_match('/\.(jpe?g|png|gif|webp)$/i', $item);
?>
    <li class="<?= $dir ? 'carpeta' : 'archivo' ?>" data-nombre="<?= htmlspecialchars($relativa) ?>">
      <?= $dir ? '📁' : iconoArchivo($item) ?>
      <?php if ($dir): ?>
        <a href="index.php?carpeta=<?= urlencode($relativa) ?>"><?= htmlspecialchars($item) ?></a>
      <?php else: ?>
        <a href="<?= htmlspecialchars($relativa) ?>" target="_blank"><?= htmlspecialchars($item) ?></a>
      <?php endif; ?>
      <?php if ($esImagen): ?>
        <img src="<?= htmlspecialchars($relativa) ?>" class="preview">
      <?php endif; ?>
    </li>
<?php endforeach; ?>
  </ul>

<?php if ($carpetaRelativa):
    $padre = dirname($carpetaRelativa);
    $back  = $padre === '.' ? '' : '?carpeta=' . urlencode($padre);
?>
  <div class="volver">
    <a href="index.php<?= $back ?>">⬅️ Volver</a>
  </div>
<?php endif; ?>


<footer class="footer">
  &copy; <?= date('Y') ?> Creawebes. Todos los derechos reservados.
</footer>

<!-- ------------- Menú contextual y modales globales ------------- -->
<div id="menu" class="menu"></div>

<!-- Modal mover -->
<div id="modalMover" class="modal">
  <div class="modal-content">
    <h2>📂 Mover elemento</h2>
    <form method="POST">
      <input type="hidden" name="accion" value="mover">
      <input type="hidden" name="archivo" id="moverArchivo">
      <label>Destino:</label>
      <select name="destino" id="selectDestino" style="width:100%;margin:1rem 0;"></select>
      <button class="btn-top" type="submit">✅ Mover</button>
      <button class="btn-top" type="button" onclick="document.getElementById('modalMover').style.display='none'">❌ Cancelar</button>
    </form>
  </div>
</div>

<!-- Modal conflicto (se inyecta sólo si error=conflicto) -->
<?php if ($error === 'conflicto' && isset($_GET['archivo'], $_GET['destino'])): ?>
<div class="modal" style="display:flex;">
  <div class="modal-content">
    <h2>⚠️ El elemento ya existe</h2>
    <p>
      <strong><?= htmlspecialchars($_GET['archivo']) ?></strong>
      ya existe en
      <strong><?= $_GET['destino'] !== '' ? htmlspecialchars($_GET['destino']) : 'Inicio' ?></strong>.
    </p>
    <p>¿Deseas reemplazarlo?</p>
    <form method="POST" style="text-align:center;">
      <input type="hidden" name="accion"  value="mover">
      <input type="hidden" name="archivo" value="<?= htmlspecialchars($_GET['archivo']) ?>">
      <input type="hidden" name="destino" value="<?= htmlspecialchars($_GET['destino']) ?>">
      <input type="hidden" name="forzar"  value="1">
      <button class="btn-top" type="submit">✅ Sí, reemplazar</button>
      <a class="btn-top" href="index.php?carpeta=<?= urlencode($carpetaRelativa) ?>">❌ Cancelar</a>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- ------------------- JavaScript ------------------- -->
<script>
let current = '';
document.querySelectorAll('.archivo,.carpeta').forEach(el => {
  el.addEventListener('contextmenu', e => {
    e.preventDefault();
    current = el.dataset.nombre;
    document.getElementById('fileSel').value = current;

    const isDir = el.classList.contains('carpeta');
    const m = document.getElementById('menu');
    m.innerHTML = '';
    if (!isDir) m.innerHTML += '<button onclick="editarArchivo()">✍️ Editar código</button>';
    m.innerHTML += '<button onclick="accion(\'renombrar\')">✏️ Renombrar</button>';
    m.innerHTML += '<button onclick="accion(\'eliminar\')">🗑️ Eliminar</button>';
    m.innerHTML += '<button onclick="accion(\'duplicar\')">📄 Duplicar</button>';
    m.innerHTML += '<button onclick="descargarArchivo()">📥 Descargar</button>';
    m.innerHTML += '<button onclick="moverArchivo()">📂 Mover</button>';

    m.style.display = 'block';
    m.style.left = e.pageX + 'px';
    m.style.top  = e.pageY + 'px';
  });
});
document.addEventListener('click', () => document.getElementById('menu').style.display = 'none');

function accion(t) {
  document.getElementById('actSel').value = t;
  if (t === 'renombrar') {
    const n = prompt('Nuevo nombre para ' + current + ':');
    if (!n) return;
    document.getElementById('newName').value = n;
  }
  document.getElementById('frm').submit();
}
function crearCarpeta() {
  const n = prompt('Nombre de nueva carpeta:');
  if (!n) return;
  document.getElementById('dirName').value = n;
  document.getElementById('frmDir').submit();
}
function editarArchivo() {
  const ruta = encodeURIComponent(current);
  window.location.href = 'editor.php?archivo=' + ruta;
}
function descargarArchivo() {
  const ruta = encodeURIComponent(current);
  window.location.href = 'download.php?archivo=' + ruta;
}
function mostrarSubida() {
  const s = document.getElementById('subida');
  s.style.display = s.style.display === 'none' ? 'block' : 'none';
}
function moverArchivo() {
  document.getElementById('moverArchivo').value = current;
  fetch('index.php?listar=1&actual=' + encodeURIComponent("<?= $carpetaRelativa ?>"))
    .then(r => r.json())
    .then(data => {
      const sel = document.getElementById('selectDestino');
      sel.innerHTML = '';
      data.forEach(c => {
        const op = document.createElement('option');
        op.value = c;
        op.textContent = '📁 ' + (c || 'Inicio');
        sel.appendChild(op);
      });
      document.getElementById('modalMover').style.display = 'flex';
    });
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
  }
});
function toggleMenuOrden() {
  const menu = document.getElementById("menuOrden");
  menu.style.display = (menu.style.display === "none" || !menu.style.display) ? "block" : "none";
}
document.addEventListener("click", function(e) {
  if (!e.target.closest('#menuOrden') && !e.target.closest('.btn-top')) {
    document.getElementById("menuOrden").style.display = "none";
  }
});
document.getElementById('buscador').addEventListener('input', function() {
  const valor = this.value.trim();
  const resultadosDiv = document.getElementById('resultadosBusqueda');

  if (valor.length < 2) {
    resultadosDiv.innerHTML = '';
    return;
  }

  fetch('buscar.php?q=' + encodeURIComponent(valor))
    .then(res => res.json())
    .then(datos => {
      if (!datos.length) {
        resultadosDiv.innerHTML = '<p style="color:gray;">🔍 No se encontraron resultados.</p>';
        return;
      }

      const html = datos.map(item => {
        const icono = item.tipo === 'carpeta' ? '📁' : '📄';
        const ruta = item.tipo === 'carpeta'
          ? 'index.php?carpeta=' + encodeURIComponent(item.ruta)
          : item.ruta;

        return `<div style="margin: .4rem 0;">
          ${icono} <a href="${ruta}" target="${item.tipo === 'archivo' ? '_blank' : '_self'}"
          style="color:#3949ab;text-decoration:none;">${item.ruta}</a>
        </div>`;
      }).join('');

      resultadosDiv.innerHTML = html;
    });
});
function abrirWhatsapp() {
    const ancho = 800;
    const alto = 600;
    const izquierda = (window.innerWidth - ancho) / 2;
    const arriba = (window.innerHeight - alto) / 2;
    window.open('https://web.whatsapp.com', 'WhatsAppChat',
      `width=${ancho},height=${alto},left=${izquierda},top=${arriba},resizable=yes,scrollbars=yes`);
  }




</script>

<!-- Formularios ocultos -->
<form id="frm" method="POST" style="display:none;">
  <input type="hidden" name="archivo"      id="fileSel">
  <input type="hidden" name="accion"       id="actSel">
  <input type="hidden" name="nuevo_nombre" id="newName">
</form>
<form id="frmDir" method="POST" style="display:none;">
  <input type="hidden" name="accion"       value="crear_carpeta">
  <input type="hidden" name="nueva_carpeta" id="dirName">
</form>
<a href="https://chatgpt.com/" target="_blank" id="btnAlfred" title="Ir a ChatGPT 🤖">
  🤖 Asistente Alfred
</a>



</body>
</html>