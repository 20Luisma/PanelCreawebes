<?php
echo password_hash('20Septiembre1981', PASSWORD_DEFAULT);

